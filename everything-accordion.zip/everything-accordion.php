﻿<?php
/*
Plugin Name: Everything Accordion
Plugin URI: https://github.com/mostafa272/Everything-Accordion
Description: The Everything Accordion is a simple widget that shows wordpress widgets, posts and pages in an pretty accordion.  
Version: 1.0
Author: Mostafa Shahiri<mostafa2134@gmail.com>
Author URI: https://github.com/mostafa272/
*/
/*  Copyright 2009  Mostafa Shahiri(email : mostafa2134@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
//register widget
add_action("widgets_init", function () { register_widget("Evac_EverythingAccordion"); });
class Evac_EverythingAccordion extends WP_Widget
{
    public function __construct() {
        parent::__construct("evac_everything_accordion", "Everything Accordion",
            array("description" => "A simple widget to show Instagram Images"));
            add_action( 'wp_enqueue_scripts',array($this,'evac_everything_accordion_scripts') );
            add_action('wp',array($this,'evac_everything_accordion_setPostViews'));
    }
    public function form($instance) {
    $getwidget=get_option('sidebars_widgets');
     global $wp_registered_widgets;
    //initial values

        $title=$instance["title"];
        $allwidgets=(!empty($instance["allwidgets"]))?$instance["allwidgets"]:array("0");
        $allposts=(!empty($instance["allposts"]))?$instance["allposts"]:array("0");
        $allcats=(!empty($instance["allcats"]))?$instance["allcats"]:array("0");
        $allpages=(!empty($instance["allpages"]))?$instance["allpages"]:array("0");
        $count=$instance["count"];
        $orderby=$instance["orderby"];
        $sort=$instance["sort"];
        $intro=$instance["intro"];
        $showcats=$instance["showcats"];
        $showauthor=$instance["showauthor"];
        $showdate=$instance["showdate"];
        $showmodified=$instance["showmodified"];
        $showcomment=$instance["showcomment"];
        $readmore=(!empty($instance["readmore"]))?$instance["readmore"]:'Read More ...';

    //title field for widget
    $titleId = $this->get_field_id("title");
    $titleName = $this->get_field_name("title");
    echo '<p><label for="'.$titleId.'">Title:</label><br>';
    echo '<input id="'.$titleId.'" type="text" name="'.$titleName.'" value="'.$title.'"></p>';

    $widgetsId = $this->get_field_id("allwidgets");
    $widgetsName = $this->get_field_name("allwidgets");
     $keys=array_keys($getwidget);
     $i=0;
     foreach($keys as $k){
     if(!is_int($getwidget[$k])){
     foreach($getwidget[$k] as $g)
    {
     $names[$i]=$g;
     $i++;
      }
     }
     }
     $allkeys=array_keys($wp_registered_widgets);
     echo '<p><label for="'.$widgetId.'">Widgets:</label><br>';
     echo '<select id="'.$widgetsId.'" name="'.$widgetsName.'[]"  multiple="true">';
     echo '<option value="0" '.selected('true', in_array('0', $allwidgets)?'true':'false' ).'>-- Select widgets --</option>';
     for($j=0;$j<count($names);$j++)
     foreach($allkeys as $a) {
    $opt=get_option($wp_registered_widgets[$a]['callback'][0]->option_name);
    $key=$wp_registered_widgets[$a]['params'][0]['number'];
     if($wp_registered_widgets[$a]['id']==$names[$j])
     echo '<option value="'.$wp_registered_widgets[$a]['id'].'" '.selected( 'true',in_array($wp_registered_widgets[$a]['id'], $allwidgets)?'true':'false' ).'>'.$wp_registered_widgets[$a]['name'].' ['.$opt[$key]['title'].']</option>';
     }
     echo '</select></p>';

     //end widgets menu
    $allpostsId = $this->get_field_id("allposts");
    $allpostsName = $this->get_field_name("allposts");
     //get all published posts
   $args = array( 'numberposts' => -1,'post_type'=>'post' ,'post_status'=>'publish');
   $posts = get_posts($args);
   echo '<p><label for="'.$allpostsId.'">Posts:</label><br>';
   echo '<select id="'.$allpostsId.'" name="'.$allpostsName.'[]" multiple="true">';
   echo '<option value="0" '.selected('true',in_array('0' , $allposts)?'true':'false' ).'>-- Select posts --</option>';
   foreach ($posts as $p){
   echo '<option value="'.$p->ID.'" '.selected( 'true' , in_array($p->ID,$allposts)?'true':'false' ).'>'.$p->post_title.'</option>';
   }
   echo '</select></p>';
      //get pages
    $allpagesId = $this->get_field_id("allpages");
    $allpagesName = $this->get_field_name("allpages");
   $pages = get_pages();
   echo '<p><label for="'.$allpagesId.'">Pages:</label><br>';
  echo '<select id="'.$allpagesId.'" name="'.$allpagesName.'[]" multiple="true">';
  echo '<option value="0" '.selected('true',in_array('0' , $allpages)?'true':'false' ).'>-- Select pages --</option>';
   foreach ($pages as $page){
   echo '<option value="'.$page->ID.'" '.selected( 'true' , in_array($page->ID,$allpages)?'true':'false' ).'>'.$page->post_title.'</option>';
   }
   echo '</select></p>';
  //get categories
    $allcatsId = $this->get_field_id("allcats");
    $allcatsName = $this->get_field_name("allcats");
   $cats = get_categories();
   echo '<p><label for="'.$allcatsId.'">Categories:</label><br>';
  echo '<select id="'.$allcatsId.'" name="'.$allcatsName.'[]" multiple="true">';
  echo '<option value="0" '.selected('true',in_array('0' , $allcats)?'true':'false' ).'>-- Select categories --</option>';
   foreach ($cats as $cat){
   echo '<option value="'.$cat->term_id.'" '.selected( 'true' , in_array($cat->term_id,$allcats)?'true':'false' ).'>'.$cat->cat_name.'</option>';
   }
   echo '</select></p>';
   //number of posts to fetch from categories
    $countId = $this->get_field_id("count");
    $countName = $this->get_field_name("count");
    echo '<p><label for="'.$countId.'">Count:</label><br>';
    echo '<input id="'.$countId.'" type="number" name="'.$countName.'" value="'.$count.'"></p>';
    //orderby box
    $orderbyId = $this->get_field_id("orderby");
    $orderbyName = $this->get_field_name("orderby");
    echo '<p><label for="'.$orderbyId.'">Order By:</label><br>';
    echo '<select id="'.$orderbyId.'" name="'.$orderbyName.'">';
    echo '<option value="date" '.selected( 'date', $orderby ).'>Created Date</option>';
    echo '<option value="modified" '.selected( 'modified', $orderby ).'>Modified Date</option>';
    echo '<option value="meta_value_num" '.selected( 'meta_value_num', $orderby ).'>Views</option>';
    echo '<option value="rand" '.selected( 'rand', $orderby ).'>Random</option>';
    echo '<option value="comment_count" '.selected( 'comment_count', $orderby ).'>Comments Count</option>';
    echo '</select></p>';
    //order type
    $sortId = $this->get_field_id("sort");
    $sortName = $this->get_field_name("sort");
    echo '<p><label for="'.$sortId.'">Order:</label><br>';
    echo '<select id="'.$sortId.'" name="'.$sortName.'">';
    echo '<option value="DESC" '.selected( 'DESC', $sort ).'>Descending</option>';
    echo '<option value="ASC" '.selected( 'ASC', $sort ).'>Ascending</option>';
    echo '</select></p>';
    //Display mode
    $introId = $this->get_field_id("intro");
    $introName = $this->get_field_name("intro");
    echo '<p><label for="'.$introId.'">Display Mode:</label><br>';
    echo '<select id="'.$introId.'" name="'.$introName.'">';
    echo '<option value="1" '.selected( 1, $intro ).'>Introtext</option>';
    echo '<option value="0" '.selected( 0, $intro ).'>Fulltext</option>';
    echo '</select></p>';
    //text for readmore link
    $readmoreId = $this->get_field_id("readmore");
    $readmoreName = $this->get_field_name("readmore");
    echo '<p><label for="'.$readmoreId.'">Read More Text:</label><br>';
    echo '<input id="'.$readmoreId.'" type="text" name="'.$readmoreName.'" value="'.$readmore.'"></p>';
    //an option for showing categories names of the posts
    $showcatsId = $this->get_field_id("showcats");
    $showcatsName = $this->get_field_name("showcats");
    ?><p><input id="<?php echo $showcatsId;?>" type="checkbox" name="<?php echo $showcatsName;?>" value="1" <?php checked( 1, $showcats );?>>Show Categories</p>
   <?php
   //an option for showing authors names of the posts or pages
   $showauthorId = $this->get_field_id("showauthor");
    $showauthorName = $this->get_field_name("showauthor");
    ?><p><input id="<?php echo $showauthorId;?>" type="checkbox" name="<?php echo $showauthorName;?>" value="1" <?php checked( 1, $showauthor );?>>Show Author</p>
   <?php
   //an option for showing published dates of the posts or pages
   $showdateId = $this->get_field_id("showdate");
   $showdateName = $this->get_field_name("showdate");
    ?><p><input id="<?php echo $showdateId;?>" type="checkbox" name="<?php echo $showdateName;?>" value="1" <?php checked( 1, $showdate );?>>Show Published Date</p>
   <?php
   //an option for showing modified dates of the posts or pages
   $showmodifiedId = $this->get_field_id("showmodified");
   $showmodifiedName = $this->get_field_name("showmodified");
    ?><p><input id="<?php echo $showmodifiedId;?>" type="checkbox" name="<?php echo $showmodifiedName;?>" value="1" <?php checked( 1, $showmodified );?>>Show Modified Date</p>
   <?php
   //an option for showing comments count of the posts or pages 
   $showcommentId = $this->get_field_id("showcomment");
   $showcommentName = $this->get_field_name("showcomment");
    ?><p><input id="<?php echo $showcommentId;?>" type="checkbox" name="<?php echo $showcommentName;?>" value="1" <?php checked( 1, $showcomment );?>>Show Comments Count</p>
   <?php

}
//sanitizing widget parameters
public function update($newInstance, $oldInstance) {
    $values = array();
    $values["title"] = sanitize_text_field($newInstance["title"]);
    $values["allwidgets"] = $newInstance["allwidgets"];
    $values["allposts"] = $newInstance["allposts"];
    $values["allcats"] = $newInstance["allcats"];
    $values["allpages"] = $newInstance["allpages"];
    $values["count"] = intval($newInstance["count"]);
    $values["orderby"] = $newInstance["orderby"];
    $values["sort"] = $newInstance["sort"];
    $values["intro"] = $newInstance["intro"];
    $values["showcats"] = $newInstance["showcats"];
    $values["showauthor"] = $newInstance["showauthor"];
    $values["showdate"] = $newInstance["showdate"];
    $values["showmodified"] = $newInstance["showmodified"];
    $values["showcomment"] = $newInstance["showcomment"];
    $values["readmore"] = sanitize_text_field($newInstance["readmore"]);
    return $values;
}
//adding CSS file and jquery accordion
function evac_everything_accordion_scripts() {
         wp_enqueue_style( 'evac-everything-accordion', plugins_url( 'css/everythingaccordion.css', __FILE__ ) );
        wp_enqueue_script('jquery-ui-accordion');
     wp_enqueue_script( 'evac-everything-accordion', plugins_url( 'js/script.js', __FILE__ ),array('jquery-ui-accordion'),'1.0',false );
}
//getting widgets from global widget array
 function evac_everything_accordion_get_widget($widgetid)
{ global $wp_registered_widgets;
     $allkeys=array_keys($wp_registered_widgets);
       if (($key = array_search("0", $widgetid)) !== false) {
    unset($widgetid[$key]);
    $widgetid=array_values($widgetid);
}
     for($j=0;$j<count($widgetid);$j++)
     foreach($allkeys as $a) {
    $opt=get_option($wp_registered_widgets[$a]['callback'][0]->option_name);
    $key=$wp_registered_widgets[$a]['params'][0]['number'];
     if($wp_registered_widgets[$a]['id']==$widgetid[$j])
     {
     $output[$j]['id']=$widgetid[$j];
     $output[$j]['classname']=get_class($wp_registered_widgets[$a]['callback'][0]);
     $output[$j]['title']=(!empty($opt[$key]['title']))?$opt[$key]['title']:$wp_registered_widgets[$a]['name'];
      }
     }
     return $output;
}
//setting post views
function evac_everything_accordion_setPostViews() {
  $postID= get_the_ID();
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
      if(is_single($postID) or is_page($postID))
      {
        $count++;
        update_post_meta($postID, $count_key, $count);
        }
    }

}

function evac_everything_accordion_get_article($articleid,$params)
{
$output=array();
//removing zero value from posts,pages or categories IDs array
 if (($key = array_search("0", $articleid)) !== false) {
    unset($articleid[$key]);
    $articleid=array_values($articleid);
   }
   //getting posts or pages based on filters
   $metakey=($params['orderby']=='meta_value_num')?'post_views_count':'';
 if($params['type']=='bypost' && !empty($articleid))
 {
   $output=get_posts(array('include'=>$articleid,'orderby'=>$params['orderby'],'order'=>$params['sort'],'meta_key'=>$metakey));
 }
 else if($params['type']=='bypage' && !empty($articleid))
 {
  $output=get_pages(array('include'=>$articleid ,'orderby'=>$params['orderby'],'meta_key'=>$metakey,'order'=>$params['sort']));
 }
 else if(($params['type']=='bycats') && $params['count']!=0 && !empty($articleid))
  {
   $output=get_posts(array('numberposts'=>$params['count'],'category'=>$articleid,'orderby'=>$params['orderby'],'order'=>$params['sort'],'meta_key'=>$metakey,'post_type'=>'post' ,'post_status'=>'publish'));
 }
  if(!empty($output))
  {  //adding extra attributes
    foreach($output as $p)
   { $tmp1=strtotime($p->post_date);
     $p->image = has_post_thumbnail($p->ID)? '<div class="accord_img">'.get_the_post_thumbnail($p->ID).'</div>':'';
      $content = get_extended($p->post_content);
      $p->intro = $content['main'];
      $p->link = ($params['type']=='bypage')?get_page_link($p->ID):get_permalink($p->ID);
      $p->post_date= date(get_option('date_format'),strtotime($p->post_date));
      $p->post_modified= date(get_option('date_format'),strtotime($p->post_modified));
      $p->author_name = get_the_author_meta('display_name',$p->post_author);
      if(($params['type']=='bycats') or $params['type']=='bypost')
      { //adding categories links for posts
      $cats=get_the_category($p->ID);
      foreach($cats as $c)
      $p->catlink=(empty($p->catlink))?'<a href="'.esc_url(get_category_link($c->term_id)).'">'.$c->cat_name.'</a>':$p->catlink.', <a href="'.esc_url(get_category_link($c->term_id)).'">'.$c->cat_name.'</a>';
      }
   }
   }
 return $output;
}

public function widget($args, $instance) {
  $title=$instance["title"];
  $widgets=$instance["allwidgets"];
  $allposts=$instance["allposts"];
  $allpages=$instance["allpages"];
  $allcats=$instance["allcats"];
  $count=$instance["count"];
  $orderby=$instance["orderby"];
  $sort=$instance["sort"];
  $intro=$instance["intro"];
  $category=$instance["showcats"];
  $author=$instance["showauthor"];
  $date=$instance["showdate"];
  $modified=$instance["showmodified"];
  $comment=$instance["showcomment"];
  $readmore=$instance["readmore"];
  //getting selected widgets
  $widget_info= $this->evac_everything_accordion_get_widget($widgets);
  //getting selected posts
  $params=array('type'=>'bypost','cats'=>0,'orderby'=>$orderby,'sort'=>$sort);
  $posts_info= $this->evac_everything_accordion_get_article($allposts,$params);
  //getting posts by selected categories
  $params=array('type'=>'bycats','count'=>$count,'orderby'=>$orderby,'sort'=>$sort);
  $postsbycats_info= $this->evac_everything_accordion_get_article($allcats,$params);
  //fetching selected pages
  $params=array('type'=>'bypage','orderby'=>$orderby,'sort'=>$sort);
  $pages_info= $this->evac_everything_accordion_get_article($allpages,$params);
  //displaying the widget on frontend. It shows the title of widget if it is not empty
  echo $args['before_widget'];
  if(!empty($title))
  {	echo $args['before_title'];
    echo esc_html($title);
  	echo $args['after_title'];
  }
//showing the selected widgets
echo '<div id="everything_accordion">';
if(!empty($widget_info))
{
for($i=0;$i<count($widget_info);$i++)
{  $ins = array('id' => $widget_info[$i]['id']);
   $ar = array( 'before_widget' => '<div class="accord_widget %s">','after_widget' => '</div>');
 echo '<h3 class="evachead">'.$widget_info[$i]['title'].'</h3>';
   the_widget($widget_info[$i]['classname'],$ins,$ar);
}
}
//display selected posts
if(!empty($posts_info))
{
 foreach($posts_info as $p)
{ $c_tmp=($category==1)?'<small class="info">Category: '.$p->catlink.'</small>':'';
  $a_tmp=($author==1)?'<small class="info">Author: '.$p->author_name.'</small>':'';
  $d_tmp=($date==1)?'<small class="info">Published: '.$p->post_date.'</small>':'';
  $m_tmp=($modified==1)?'<small class="info">Modified: '.$p->post_modified.'</small>':'';
  $com_tmp=($comment==1)?'<small class="info">Comments: '.$p->comment_count.'</small>':'';
  $info_block=(!empty($c_tmp.$a_tmp.$d_tmp.$m_tmp.$com_tmp))?'<div class="infoblock">'.$c_tmp.$a_tmp.$d_tmp.$m_tmp.$com_tmp.'</div>':'';
 echo '<h3 class="evachead">'.$p->post_title.'</h3>';
 echo ($intro==1)?'<div class="accord_content">'.$p->image.$info_block.'<div class="accord_post">'.$p->intro.'</div><div class="accord_readmore"><a  href="'.esc_url($p->link).'">'.esc_html($readmore).'</a></div></div>':'<div class="accord_content">'.$info_block.'<div class="accord_post">'.$p->post_content.'</div></div>';
}
}
//display posts selected by categories
if(!empty($postsbycats_info))
{
 foreach($postsbycats_info as $c)
{
  $c_tmp=($category==1)?'<small class="info">Category: '.$c->catlink.'</small>':'';
  $a_tmp=($author==1)?'<small class="info">Author: '.$c->author_name.'</small>':'';
  $d_tmp=($date==1)?'<small class="info">Published: '.$c->post_date.'</small>':'';
  $m_tmp=($modified==1)?'<small class="info">Modified: '.$c->post_modified.'</small>':'';
  $com_tmp=($comment==1)?'<small class="info">Comments: '.$c->comment_count.'</small>':'';
  $info_block=(!empty($c_tmp.$a_tmp.$d_tmp.$m_tmp.$com_tmp))?'<div class="infoblock">'.$c_tmp.$a_tmp.$d_tmp.$m_tmp.$com_tmp.'</div>':'';
 echo '<h3 class="evachead">'.$c->post_title.'</h3>';
 echo ($intro==1)?'<div class="accord_content">'.$c->image.$info_block.'<div class="accord_post">'.$c->intro.'</div><div class="accord_readmore"><a href="'.esc_url($c->link).'">'.esc_html($readmore).'</a></div></div>':'<div class="accord_content">'.$info_block.'<div class="accord_post">'.$c->post_content.'</div></div>';
}
}
//display selected pages
if(!empty($pages_info))
{
 foreach($pages_info as $page)
{
  $a_tmp=($author==1)?'<small class="info">Author: '.$page->author_name.'</small>':'';
  $d_tmp=($date==1)?'<small class="info">Published: '.$page->post_date.'</small>':'';
  $m_tmp=($modified==1)?'<small class="info">Modified: '.$page->post_modified.'</small>':'';
  $com_tmp=($comment==1)?'<small class="info">Comments: '.$page->comment_count.'</small>':'';
  $info_block=(!empty($a_tmp.$d_tmp.$m_tmp.$com_tmp))?'<div class="infoblock">'.$a_tmp.$d_tmp.$m_tmp.$com_tmp.'</div>':'';
 echo '<h3 class="evachead">'.$page->post_title.'</h3>';
 echo ($intro==1)?'<div class="accord_content">'.$page->image.$info_block.'<div class="accord_post">'.$page->intro.'</div><div class="accord_readmore"><a class="accord_readmore" href="'.esc_url($page->link).'">'.esc_html($readmore).'</a></div></div>':'<div class="accord_content">'.$info_block.'<div class="accord_post">'.$page->post_content.'</div></div>';
}
}
echo '</div>';

 echo $args['after_widget'];
}
}
