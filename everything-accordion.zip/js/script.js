  jQuery(function() {
    jQuery( "#everything_accordion" ).accordion({
      collapsible: true, header:"h3.evachead",heightStyle:"content"
    });
  });